/*----------------------------------------------------------
 *				HTBLA-Leonding / Klasse: 2AHIF
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			trim.h
 * Author:			Patrick Spisak
 * ----------------------------------------------------------
 * Description:
 * Interface for trim
 * ----------------------------------------------------------
 */

#ifndef __STRLEN_H
#define __STRLEN_H

#define STRLEN 17                //Die Länge muss so lang sein, wie der längste Chararray in test_trim.cpp + 1
                                    //Wenn diese konstante Länge nur genauso lang wäre, wie der längste Array in test_trim.cpp, dann wäre /0 ein invalider Index d.h es kommt eine Errormeldung!
#include <stdio.h>
#include <string.h>

void trim	(	const char * 	source, char * 	trimmed_string);


#endif
