/*----------------------------------------------------------
 *				HTBLA-Leonding / Klasse: 2AHIF
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			trim.cpp
 * Author:			Patrick Spisak
 * ----------------------------------------------------------
 * Description:
 * Test functions for trim.h
 * ----------------------------------------------------------
 */
 #include <stdio.h>
 #include <string.h>
 #include "trim.h"

static void trim_left_and_right(const char *	source, char * 	trimmed_string)
{
  int counter = 0;
  char charArray [STRLEN];

  for(int i = 0;i < STRLEN;i++)
  {
    if(i == 0 && source[i] == ' '|| strlen(source) >= 1 && i == (strlen(source)-1) && source[i] == ' ' )
    {
      //Do Nothing
    }

    else if(source[i] != ' ' || (source[i] == ' ' && source[(i-1)] != ' ' && source[(i+1)] != ' '))
    {
      charArray[counter] = source[i];
      counter++;
    }

  }
  strcpy(trimmed_string, charArray);

  printf("trimmed_string : %s\n",trimmed_string );
  printf("charArray : %s \n",charArray);
}

void trim	(	const char *	source, char * 	trimmed_string)
{
  trim_left_and_right(source, trimmed_string);
}
